package com.amrita.se.emailapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailappApplicationTests {
    @Test
    void contextLoads() {
    }

}
