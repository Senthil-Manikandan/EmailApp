package com.amrita.se.emailapp.payload.request;

public class GetTemplateRequest {
    private Long templateId;
    public Long getTemplateId() {
        return templateId;
    }
    public void setTemplateId(Long templateId) {
        this.templateId = templateId;
    }
}
