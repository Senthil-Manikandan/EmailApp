package com.amrita.se.emailapp.Exception;

public class ConfigDataResourceNotFoundException extends  Exception{
    public ConfigDataResourceNotFoundException(String errorMessage) {
        super(errorMessage);
    }
}
