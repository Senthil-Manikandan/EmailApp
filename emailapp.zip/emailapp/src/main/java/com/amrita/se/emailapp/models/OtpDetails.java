package com.amrita.se.emailapp.models;

public class OtpDetails {
}
