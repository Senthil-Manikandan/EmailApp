package com.amrita.se.emailapp.payload.request;

public class InboxEmailRequest {
    private String receiverEmail;

    public String getReceiverEmail() {
        return receiverEmail;
    }

    public void setReceiverEmail(String receiverEmail) {
        this.receiverEmail = receiverEmail;
    }


}
