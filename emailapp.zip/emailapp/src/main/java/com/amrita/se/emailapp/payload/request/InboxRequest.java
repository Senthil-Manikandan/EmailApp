package com.amrita.se.emailapp.payload.request;

public class InboxRequest {

    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
